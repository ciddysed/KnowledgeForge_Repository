package com.g1AppDev.KnowledgeForge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnowledgeForgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
