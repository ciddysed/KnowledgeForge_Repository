package com.g1AppDev.KnowledgeForge.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.g1AppDev.KnowledgeForge.Entity.StudentSelection;
import com.g1AppDev.KnowledgeForge.Repository.StudentSelectionRepository;

@Service
public class StudentSelectionService {

    @Autowired
    private StudentSelectionRepository studentSelectionRepository;

    // Method to get list of students who selected a specific tutor
    public List<StudentSelection> getStudentsByTutor(String tutorUsername) {
        return studentSelectionRepository.findByTutorUsername(tutorUsername);
    }

    // Method to save a student selection
    public StudentSelection saveStudentSelection(StudentSelection studentSelection) {
        return studentSelectionRepository.save(studentSelection);
    }
}
