package com.g1AppDev.KnowledgeForge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnowledgeForgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnowledgeForgeApplication.class, args);
	}

}
