package com.g1AppDev.KnowledgeForge.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.g1AppDev.KnowledgeForge.Entity.StudentSelection;
import com.g1AppDev.KnowledgeForge.Service.StudentSelectionService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/notifications")
public class StudentSelectionController {

    @Autowired
    private StudentSelectionService studentSelectionService;

    // Endpoint to get students who selected a particular tutor
    @GetMapping("/{tutorUsername}")
    public List<StudentSelection> getStudentsForTutor(@PathVariable String tutorUsername) {
        return studentSelectionService.getStudentsByTutor(tutorUsername);
    }

     @PostMapping("/select")
    public StudentSelection selectTutor(@RequestBody StudentSelection studentSelection) {
        return studentSelectionService.saveStudentSelection(studentSelection);
    }
}