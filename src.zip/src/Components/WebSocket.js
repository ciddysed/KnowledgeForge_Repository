import SockJS from 'sockjs-client';
import Stomp from 'stompjs';

let stompClient = null;
let subscriptionQueue = [];

export const connectWebSocket = (onConnectedCallback) => {
    const socket = new SockJS('http://localhost:8080/ws');
    stompClient = Stomp.over(socket);

    stompClient.connect({}, (frame) => {
        console.log('WebSocket connected:', frame);
        if (onConnectedCallback) {
            onConnectedCallback();
        }
        // Process any queued subscriptions
        subscriptionQueue.forEach(({ tutorUsername, callback }) => {
            subscribeToTutorNotifications(tutorUsername, callback);
        });
        subscriptionQueue = [];
    }, (error) => {
        console.error('WebSocket connection error:', error);
        // Retry connection after a delay
        setTimeout(() => {
            connectWebSocket(onConnectedCallback);
        }, 5000);
    });
};

// Function to send a message from a specific student to a specific tutor
export const sendNotification = (tutorUsername, studentMessage) => {
    if (stompClient && stompClient.connected) {
        console.log(`Sending notification to tutor: ${tutorUsername}, message: ${studentMessage}`);
        stompClient.send(`/app/notifyTutor/${tutorUsername}`, {}, JSON.stringify(studentMessage));
    } else {
        console.error("WebSocket is not connected. Cannot send notification.");
    }
};

// Function to subscribe to notifications for a specific tutor
export const subscribeToTutorNotifications = (tutorUsername, callback) => {
    if (stompClient) {
        if (stompClient.connected) {
            console.log(`Subscribing to notifications for tutor: ${tutorUsername}`);
            const destination = `/topic/notification/tutor/${tutorUsername}`;
            stompClient.subscribe(destination, (message) => {
                const parsedMessage = JSON.parse(message.body);
                callback(parsedMessage); // Pass parsed message to callback
            });
        } else {
            console.error("WebSocket is not connected. Queuing subscription.");
            subscriptionQueue.push({ tutorUsername, callback });
        }
    } else {
        console.error("WebSocket client is not initialized.");
    }
};