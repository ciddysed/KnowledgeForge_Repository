import React, { useEffect, useState } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { connectWebSocket, sendNotification, subscribeToTutorNotifications } from './WebSocket';

const Notifications = () => {
  const [students, setStudents] = useState([]);
  const [tutorUsername, setTutorUsername] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    const loggedInTutor = JSON.parse(localStorage.getItem('loggedInUser'));
    if (!loggedInTutor || !loggedInTutor.username) {
      console.error("No logged in user found in localStorage or username is missing");
      return;
    }

    const tutorUsername = loggedInTutor.username;
    setTutorUsername(tutorUsername);
    console.log(`Logged in tutor username: ${tutorUsername}`);

    const fetchStudents = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/notifications/${tutorUsername}`);
        if (response.ok) {
          const data = await response.json();
          setStudents(data);
        } else {
          setError('Failed to fetch students.');
          console.error('Failed to fetch students:', response.statusText);
        }
      } catch (error) {
        setError('Error fetching students. Please try again.');
        console.error('Error fetching students:', error);
      }
    };

    fetchStudents();

    connectWebSocket(() => {
      console.log('WebSocket connected, ready to subscribe to notifications');
      subscribeToTutorNotifications(tutorUsername, (message) => {
        try {
          console.log("Received message:", message); // Log incoming messages for debugging
          const newStudent = message;
          if (newStudent && newStudent.studentUsername && newStudent.tutorId) {
            setStudents((prevStudents) => [...prevStudents, newStudent]);

            // Show a toast notification for the new student
            toast.success(`New student selected you: ${newStudent.studentUsername}`);
          }
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
          toast.error('Error processing the notification.');
        }
      });
    });

  }, [tutorUsername]);

  const handleAccept = async (student) => {
    try {
      sendNotification(student.studentUsername, { tutorUsername, tutorId: student.tutorId });
      // Removed toast notification from here
    } catch (error) {
      console.error("Error sending acceptance notification:", error);
      toast.error("Failed to send acceptance notification.");
    }
  };

  return (
    <div>
      <ToastContainer /> {/* Toast container for displaying notifications */}
      <h1>Students Who Chose You as a Tutor</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {students.length === 0 ? (
        <p>No students have selected you yet.</p>
      ) : (
        <ul>
          {students.map((student) => (
            <li key={student.id}>
              <strong>{student.studentUsername}</strong> - {student.tutorId}
              <button onClick={() => handleAccept(student)}>Accept</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Notifications;