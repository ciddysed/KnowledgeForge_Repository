import React, { useEffect, useState } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { connectWebSocket, sendNotification, subscribeToTutorNotifications } from './WebSocket';

const TutorSearch = () => {
  const [tutors, setTutors] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('All');
  const [filteredTutors, setFilteredTutors] = useState([]);
  const [isLoading, setIsLoading] = useState(true); // New state variable

  useEffect(() => {
    const fetchTutors = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/tutors');
        const data = await response.json();
        console.log("Fetched tutors:", data);
        setTutors(data);
        setFilteredTutors(data);
      } catch (error) {
        console.error("Error fetching tutors:", error);
      } finally {
        setIsLoading(false); // Set loading to false after fetching
      }
    };

    fetchTutors();

    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

    try {
      connectWebSocket(() => {
        console.log('WebSocket connected, ready to subscribe to notifications');
        try {
          subscribeToTutorNotifications(loggedInUser.username, (message) => {
            if (message.tutorUsername === loggedInUser.username) {
              toast.success(`You have been accepted by ${message.tutorUsername}`);
            }
          });
        } catch (error) {
          console.error("Error subscribing to tutor notifications:", error);
        }
      });
    } catch (error) {
      console.error("Error connecting to WebSocket:", error);
    }

  }, []);

  const handleCourseChange = (e) => {
    const selected = e.target.value;
    setSelectedCourse(selected);

    if (selected === "All") {
      setFilteredTutors(tutors);
    } else {
      const filtered = tutors.filter(
        (tutor) => tutor.courseMajor === selected
      );
      setFilteredTutors(filtered);
    }
  };

  const handleChoose = async (tutor) => {
    console.log("Selected tutor:", tutor);
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

    if (!loggedInUser || !loggedInUser.username) {
      console.error('No student logged in');
      alert("Please log in to select a tutor.");
      return;
    }

    const studentUsername = loggedInUser.username;

    if (!tutor.username) {
      console.error("No tutor username available for this tutor.");
      alert("This tutor does not have a valid username.");
      return;
    }

    // Prompt for confirmation
    const confirmSelection = window.confirm(`Are you sure you want to choose ${tutor.tutorName} as your tutor?`);
    if (!confirmSelection) {
      return;
    }

    console.log("tutorUsername:", tutor.username);
    sendNotification(tutor.username, { studentUsername, tutorId: tutor.tutorID });
    alert(`You notified ${tutor.tutorName}`);

    // Save the student-tutor selection in the database
    try {
      const response = await fetch('http://localhost:8080/api/notifications/select', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ studentUsername, tutorUsername: tutor.username, tutorId: tutor.tutorID }),
      });

      if (response.ok) {
        alert(`You notified ${tutor.tutorName} and your selection has been saved.`);
      } else {
        alert("Failed to save your selection.");
      }
    } catch (error) {
      console.error("Error saving student selection:", error);
      alert("There was an error while saving your selection.");
    }
  };

  const courseMajors = ["All", ...new Set(tutors.map((tutor) => tutor.courseMajor))];

  return (
    <div>
      <ToastContainer /> {/* Toast container for displaying notifications */}
      <h1>Available Tutors</h1>
      <select value={selectedCourse} onChange={handleCourseChange}>
        {courseMajors.map((course, index) => (
          <option key={index} value={course}>{course}</option>
        ))}
      </select>

      {isLoading ? ( // Display loading message if isLoading is true
        <p>Loading tutors...</p>
      ) : (
        <div>
          {filteredTutors.map((tutor) => (
            <div key={tutor.tutorID}>
              <h2>{tutor.tutorName}</h2>
              <button onClick={() => handleChoose(tutor)}>Choose</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TutorSearch;